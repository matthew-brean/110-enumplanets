

public class DaysOfWeek{ //actually planets
    Planets planet;
    
    
    public enum Planets {
		//Sun ,
		Mercury,
		Venus,
		Earth,
		Mars,
		Jupiter,
		Saturn,
		Uranus,
		Neptune
}
    public DaysOfWeek(Planets planets) {
        this.planet = planets;
    }
    
    public void myFunction() {
        
    	switch (planet) {
    	
    	
          
         //i have realized that in fact the sun is not a planet ... 
         
          //case Sun:
               // System.out.println("Sun");
               // break;
                    
            case Mercury:
                System.out.println("Mercury");
                break;
                
                
   case Venus:
       System.out.println("Venus");
       break;                         
   case Earth:
       System.out.println("Earth");
       break;                         
   case Mars:
       System.out.println("Mars");
       break;                         
   case Jupiter:
       System.out.println("Jupiter");
       break;                         
   case Saturn:
       System.out.println("Saturn");
       break;
       
case Uranus:
System.out.println("Uranus");
break;                         
case Neptune:
    System.out.println("Neptune");
    break;
                        
                
            default:
                System.out.println("no planet");
                break;
        }
    }
    
    public static void main(String[] args) {
        //DaysOfWeek firstPlanet = new DaysOfWeek(Planets.Sun);
        //firstPlanet.myFunction();
        DaysOfWeek secondPlanet = new DaysOfWeek(Planets.Mercury);
        secondPlanet.myFunction();
        DaysOfWeek thirdPlanet = new DaysOfWeek(Planets.Venus);
        thirdPlanet.myFunction();
        DaysOfWeek fourthPlanet = new DaysOfWeek(Planets.Earth);
        fourthPlanet.myFunction();
        DaysOfWeek fifthPlanet = new DaysOfWeek(Planets.Mars);
        fifthPlanet.myFunction();
        DaysOfWeek sixthPlanet = new DaysOfWeek(Planets.Jupiter);
        sixthPlanet.myFunction();
        DaysOfWeek seventhPlanet = new DaysOfWeek(Planets.Saturn);
        seventhPlanet.myFunction();
        DaysOfWeek eighthPlanet = new DaysOfWeek(Planets.Uranus);
        eighthPlanet.myFunction();
        DaysOfWeek ninethPlanet = new DaysOfWeek(Planets.Neptune);
        ninethPlanet.myFunction();

    
    }
}